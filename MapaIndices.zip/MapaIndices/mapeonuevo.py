import json
import re
import os
import logging
from datetime import datetime
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from elasticsearch import Elasticsearch
from openpyxl import Workbook

# Configuración global
OUTPUT_DIR = "output"
LOG_PATH = os.path.join(OUTPUT_DIR, "output.log")
EXCEL_PATH = os.path.join(OUTPUT_DIR, "indices_elasticsearch.xlsx")
CONFIG_PATH = os.path.join("configuracion", "conexion.json")
MAX_WORKERS = 8  # Ajustable

def configurar_logging():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(LOG_PATH, encoding="utf-8"),
            logging.StreamHandler()
        ],
        force=True
    )

def cargar_configuracion():
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)["elastic"]

def conectar_elasticsearch(cfg):
    es = Elasticsearch(
        cfg["nodes"],
        basic_auth=(cfg["username"], cfg["password"]),
        verify_certs=False
    )
    if not es.ping():
        raise Exception("No se pudo conectar a Elasticsearch")
    return es

def obtener_alias(index_name):
    if re.search(r"\d", index_name) and "-" in index_name:
        return "-".join(index_name.split("-")[:-1])
    return index_name

def formatear_fecha(ms):
    try:
        ts = int(ms)
        return datetime.utcfromtimestamp(ts / 1000).strftime("%d/%m/%Y"), ts
    except:
        return "inv", 0

def validar_indice(es, index_info):
    nombre = index_info["index"]
    if nombre.startswith("."):
        return None

    try:
        mapping = es.indices.get_mapping(index=nombre).get(nombre, {})
        props = mapping.get("mappings", {}).get("properties", {})

        if (
            "measurement_name" in props and
            "tag" in props and
            "type" in props["tag"].get("properties", {}) and
            "model" in props["tag"].get("properties", {})
        ):
            alias = obtener_alias(nombre)
            fecha, raw_fecha = formatear_fecha(index_info["creation.date"])

            # ✔️ Obtener el count exacto con /<index>/_count
            try:
                res = es.count(index=nombre)
                count_real = res["count"]
            except Exception as e:
                logging.warning(f"No se pudo obtener count exacto para {nombre}: {e}")
                count_real = int(index_info["docs.count"])  # fallback

            return alias, (nombre, count_real, fecha, index_info["status"], raw_fecha)
    except Exception as e:
        logging.warning(f"Saltando índice inválido: {nombre} ({str(e)})")

    return None

def main():
    configurar_logging()
    cfg = cargar_configuracion()
    es = conectar_elasticsearch(cfg)

    logging.info("Obteniendo índices...")
    indices = es.cat.indices(index="*", format="json", h="index,creation.date,status,docs.count")

    logging.info(f"Procesando {len(indices)} índices en paralelo...")
    indices_validos = defaultdict(list)

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(validar_indice, es, idx) for idx in indices]
        for future in as_completed(futures):
            resultado = future.result()
            if resultado:
                alias, data = resultado
                indices_validos[alias].append(data)

    logging.info(f"Total prefijos válidos: {len(indices_validos)}")

    wb = Workbook()
    ws1 = wb.active
    ws1.title = "Indices Validos"
    ws1.append(["Alias", "Index", "Docs", "Fecha", "Status"])

    for alias, items in indices_validos.items():
        for idx in items:
            ws1.append([alias] + list(idx[:4]))

    # Hoja de penúltimos
    ws2 = wb.create_sheet("Penultimos por Prefijo")
    ws2.append(["Alias", "Index", "Docs", "Fecha", "Status"])

    for alias, items in indices_validos.items():
        items = sorted(items, key=lambda x: x[4])  # Ordenar por fecha
        if len(items) == 1:
            ws2.append([alias] + list(items[0][:4]))
        else:
            pen = items[-2]
            ws2.append([alias] + list(pen[:4]))

    wb.save(EXCEL_PATH)
    logging.info(f"✅ Excel generado: {EXCEL_PATH}")

if __name__ == "__main__":
    main()
