import os
import json
import logging
from elasticsearch import Elasticsearch
from elasticsearch.exceptions import NotFoundError
from openpyxl import Workbook, load_workbook

CONFIG_PATH = "configuracion/conexion.json"
INDICES_PATH = "output/tmp/indices.txt"
OUTPUT_DIR = "output"
EXCEL_PATH = os.path.join(OUTPUT_DIR, "indices_elasticsearch.xlsx")
LOG_PATH = os.path.join(OUTPUT_DIR, "output.log")

os.makedirs(OUTPUT_DIR, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH, encoding="utf-8"),
        logging.StreamHandler()
    ],
    force=True
)

def cargar_configuracion():
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)["elastic"]

def conectar_elasticsearch(cfg):
    for nodo in cfg["nodes"]:
        try:
            es = Elasticsearch(
                [nodo],
                basic_auth=(cfg["username"], cfg["password"]),
                verify_certs=False
            )
            if es.ping():
                logging.info(f"✅ Nodo seleccionado: {nodo}")
                return es
            else:
                logging.warning(f"⚠️ Nodo sin respuesta: {nodo}")
        except Exception as e:
            logging.warning(f"❌ Error conectando a {nodo}: {e}")
    raise Exception("❌ No fue posible conectar a ningún nodo disponible.")

def cargar_indices():
    with open(INDICES_PATH, "r") as f:
        return [line.strip() for line in f if line.strip()]

def normalizar(valor):
    return valor if valor not in (None, "", " ") else "null"

def construir_aggs(use_keyword=False):
    def campo(field):
        return field if not use_keyword else field + ".keyword"

    return {
        "group_by": {
            "composite": {
                "size": 100,
                "sources": [
                    { "measurement_name": { "terms": { "field": campo("measurement_name") } } },
                    { "tag_type":          { "terms": { "field": campo("tag.type") } } },
                    { "tag_model":         { "terms": { "field": campo("tag.model") } } }
                ]
            }
        }
    }

def extraer_datos_composite(es, indice):
    resultados = []
    after_key = None
    usar_keyword = False

    while True:
        body = {
            "size": 0,
            "query": {
                "bool": {
                    "must": [
                        { "exists": { "field": "measurement_name" } },
                        { "exists": { "field": "tag.type" } },
                        { "exists": { "field": "tag.model" } }
                    ]
                }
            },
            "aggs": construir_aggs(usar_keyword)
        }

        if after_key:
            body["aggs"]["group_by"]["composite"]["after"] = after_key

        try:
            res = es.search(index=indice, body=body, request_timeout=180)
        except NotFoundError:
            logging.warning(f"❌ Índice no encontrado: {indice}")
            break
        except Exception as e:
            msg = str(e)
            if ("Fielddata is disabled" in msg or 
                "Can't aggregate" in msg or 
                "not a keyword" in msg) and not usar_keyword:
                logging.warning(f"⚠️ Campo no keyword en {indice}, reintentando con .keyword")
                usar_keyword = True
                continue
            logging.error(f"❌ Error consultando índice {indice}: {msg}")
            break

        group = res.get("aggregations", {}).get("group_by", {})
        buckets = group.get("buckets", [])
        for b in buckets:
            resultados.append({
                "measurement_name": normalizar(b["key"].get("measurement_name")),
                "type": normalizar(b["key"].get("tag_type")),
                "model": normalizar(b["key"].get("tag_model")),
                "doc_count": b.get("doc_count", 0)
            })

        after_key = group.get("after_key")
        if not after_key:
            break

    return resultados

def agregar_hoja_excel(indice, datos):
    # Cargar el archivo Excel existente o crear uno nuevo
    if os.path.exists(EXCEL_PATH):
        wb = load_workbook(EXCEL_PATH)
    else:
        wb = Workbook()
        # Eliminar la hoja por defecto si es nueva
        if "Sheet" in wb.sheetnames:
            wb.remove(wb["Sheet"])
    
    # Crear o reemplazar la hoja del índice
    if indice in wb.sheetnames:
        wb.remove(wb[indice])
    
    ws = wb.create_sheet(title=indice)
    
    # Escribir encabezados
    headers = ["measurement_name", "type", "model", "doc_count"]
    for col, header in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=header)
    
    # Escribir datos
    for row_idx, row_data in enumerate(datos, 2):
        ws.cell(row=row_idx, column=1, value=row_data["measurement_name"])
        ws.cell(row=row_idx, column=2, value=row_data["type"])
        ws.cell(row=row_idx, column=3, value=row_data["model"])
        ws.cell(row=row_idx, column=4, value=row_data["doc_count"])
    
    wb.save(EXCEL_PATH)
    logging.info(f"✅ Hoja '{indice}' agregada al Excel principal")

def ejecutar():
    cfg = cargar_configuracion()
    es = conectar_elasticsearch(cfg)
    indices = cargar_indices()
    
    logging.info(f"📊 Procesando {len(indices)} índices en el archivo Excel principal")
    
    for indice in indices:
        logging.info(f"🔎 Procesando índice: {indice}")
        try:
            datos = extraer_datos_composite(es, indice)
            if datos:
                agregar_hoja_excel(indice, datos)
                logging.info(f"✅ Índice '{indice}' procesado: {len(datos)} filas")
            else:
                logging.warning(f"⚠️ Sin datos válidos en: {indice}")
        except Exception as e:
            logging.error(f"❌ Error procesando {indice}: {str(e)}")
    
    logging.info(f"🎯 Procesamiento completado. Archivo Excel: {EXCEL_PATH}")

if __name__ == "__main__":
    ejecutar()
