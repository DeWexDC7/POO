import os
import logging
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill

# Rutas
EXCEL_PATH = "output/indices_elasticsearch.xlsx"
HOJA_REFERENCIA = "Penultimos por Prefijo"
HOJA_RESULTADO = "diferencia"
ENCABEZADOS = ["index", "docs_count", "combinacion_count", "diferencia"]

# Configurar logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def main():
    if not os.path.exists(EXCEL_PATH):
        logging.error("❌ Archivo Excel no encontrado.")
        return

    # Cargar todas las hojas con pandas
    hojas = pd.read_excel(EXCEL_PATH, sheet_name=None, engine="openpyxl")

    if HOJA_REFERENCIA not in hojas:
        logging.error(f"❌ Falta la hoja '{HOJA_REFERENCIA}'.")
        return

    df_ref = hojas[HOJA_REFERENCIA]

    # Validación columnas esperadas
    if "Index" not in df_ref.columns or "Docs" not in df_ref.columns:
        logging.error("❌ Columnas 'Index' y 'Docs' no encontradas en hoja de referencia.")
        return

    resultados = []

    for _, fila in df_ref.iterrows():
        nombre_hoja = fila["Index"]
        docs_count = fila["Docs"]

        if pd.isna(nombre_hoja) or pd.isna(docs_count):
            logging.warning(f"⚠️ Datos faltantes: {fila}")
            continue

        if nombre_hoja not in hojas:
            logging.warning(f"⚠️ Hoja '{nombre_hoja}' no encontrada en el Excel.")
            continue

        df_hoja = hojas[nombre_hoja]

        if "doc_count" not in df_hoja.columns:
            logging.warning(f"⚠️ Hoja '{nombre_hoja}' no tiene columna 'doc_count'.")
            continue

        suma = df_hoja[df_hoja["model"].str.upper() != "TOTAL"]["doc_count"].sum()
        diferencia = int(docs_count) - int(suma)

        resultados.append([nombre_hoja, int(docs_count), int(suma), diferencia])
        logging.info(f"🟰 {nombre_hoja}: {docs_count} - {suma} = {diferencia}")

    # Crear DataFrame resultado
    df_dif = pd.DataFrame(resultados, columns=ENCABEZADOS)

    # Cargar el archivo con openpyxl para insertar la nueva hoja
    wb = load_workbook(EXCEL_PATH)
    if HOJA_RESULTADO in wb.sheetnames:
        del wb[HOJA_RESULTADO]

    from openpyxl.utils.dataframe import dataframe_to_rows
    ws = wb.create_sheet(HOJA_RESULTADO)
    ws.sheet_properties.tabColor = "FF0000"

    for r in dataframe_to_rows(df_dif, index=False, header=True):
        ws.append(r)

    wb.save(EXCEL_PATH)
    logging.info("✅ Hoja 'diferencia' generada con pandas y guardada.")

if __name__ == "__main__":
    main()
