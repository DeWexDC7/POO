ejemplo del indice t series buscamos en todos los documentos los campos 

 -> "measurement_name" : ejemplo campo a 
 -> "tag_type" :b 1
 -> "tag_model" : c 2

    de esos tres campos me debo jalar todas las combinaciones posibles en este ejemplo a b c 

