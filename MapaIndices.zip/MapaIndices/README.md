# Generador de Hojas por Índices

Este script crea un nuevo archivo Excel con una hoja separada para cada índice encontrado en el archivo original. Cada hoja se nombra según el índice correspondiente.

## Requisitos

- Python 3.6 o superior
- Bibliotecas: pandas, openpyxl

Para instalar las bibliotecas necesarias:
```
pip install pandas openpyxl
```

## Uso

### Método 1: Ejecutar el script directamente

```
python create_index_worksheets.py [archivo_entrada.xlsx] [archivo_salida.xlsx]
```

Si no proporciona los argumentos, el programa le pedirá la ruta del archivo de entrada.

### Método 2: Importar la función en otro script

```python
from create_index_worksheets import create_index_worksheets

create_index_worksheets("ruta/al/archivo_entrada.xlsx", "ruta/al/archivo_salida.xlsx")
```

## Ejemplo

Si tiene un archivo Excel con una columna llamada "Indice" y valores como "A1", "B2", etc., el script creará un nuevo archivo Excel con hojas separadas llamadas "A1", "B2", etc., cada una conteniendo solo las filas correspondientes a ese índice.

## Notas

- El script busca automáticamente una columna que contenga la palabra "indice" (sin distinción entre mayúsculas y minúsculas)
- Si la columna de índice no se puede encontrar, el script mostrará un mensaje de error
- Los nombres de las hojas están limitados a 31 caracteres (limitación de Excel)
