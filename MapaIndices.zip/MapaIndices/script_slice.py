import os
import logging
import pandas as pd  # Asegúrate de tener pandas importado

# Configuración global
OUTPUT_DIR = "output"
LOG_PATH = os.path.join(OUTPUT_DIR, "output.log")
EXCEL_PATH = os.path.join(OUTPUT_DIR, "indices_elasticsearch.xlsx")
TXT_PATH = os.path.join(OUTPUT_DIR, "nombre_indice.txt")

# Configurar logging
def configurar_logging():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(LOG_PATH, encoding="utf-8"),
            logging.StreamHandler()
        ],
        force=True
    )

# Acceder a la columna Index de la hoja Penultimos por Prefijo
def acceder_excel_y_guardar_indices():
    try:
        hoja_nombre = "Penultimos por Prefijo"
        # Leer el archivo Excel y la hoja específica
        df = pd.read_excel(EXCEL_PATH, sheet_name=hoja_nombre)

        # Verificar si la columna 'Index' existe en el DataFrame
        if 'Index' in df.columns:
            # Obtener los valores de la columna 'Index' como una lista, eliminando los valores nulos
            indices = df['Index'].dropna().tolist()

            # Crear un directorio temporal para guardar el archivo de salida
            os.makedirs(os.path.join(OUTPUT_DIR, "tmp"), exist_ok=True)

            # Guardar los índices en un archivo .txt
            with open(os.path.join(OUTPUT_DIR, "tmp", "indices.txt"), "w") as f:
                f.write("\n".join(indices))  # Guardar cada índice en una línea

            logging.info(f"Indices guardados en: {os.path.join(OUTPUT_DIR, 'tmp', 'indices.txt')}")
            return indices  # Retornar la lista de índices

        else:
            logging.error(f"La hoja '{hoja_nombre}' no contiene la columna 'Index'.")
            return []

    except FileNotFoundError:
        logging.error(f"El archivo '{EXCEL_PATH}' no se encontró.")
        return []
    except Exception as e:
        logging.error(f"Error al procesar el archivo Excel: {e}")
        return []

# Función principal
def main():
    configurar_logging()
    
    # Llamar a la función para acceder al Excel y generar el archivo .txt
    indices = acceder_excel_y_guardar_indices()

    if indices:
        logging.info(f"Se han generado {len(indices)} índices en el archivo .txt.")
    else:
        logging.error("No se generaron índices en el archivo .txt.")

# Asegurarse de que se ejecute solo cuando el script se ejecute directamente
if __name__ == "__main__":
    main()
