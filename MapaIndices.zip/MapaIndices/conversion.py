import os
import json
import logging
import psycopg2
import pandas as pd
from openpyxl import load_workbook, Workbook
from openpyxl.utils import get_column_letter

# Rutas
CONFIG_PATH = "configuracion/conexion.json"
EXCEL_PATH = "output/indices_elasticsearch.xlsx"
LOG_PATH = "output/output.log"
ENCABEZADOS = ["measurement_name", "type", "model", "doc_count"]
ENCABEZADOS_DIFERENCIA = ["index", "docs_count", "combinacion_count", "diferencia"]

# Crear carpeta para logs si no existe
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

# Configuración Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH, encoding="utf-8"),
        logging.StreamHandler()
    ],
    force=True
)

# Leer configuración
with open(CONFIG_PATH, "r") as f:
    config = json.load(f)
pg_conf = config["postgresql"]

# Conectar a PostgreSQL
conn = psycopg2.connect(**pg_conf)
cursor = conn.cursor()

# Crear esquema si no existe
try:
    cursor.execute("""
        CREATE SCHEMA IF NOT EXISTS mapeo_indice;
    """)
    conn.commit()
    logging.info("✅ Esquema 'mapeo_indice' creado o ya existe")
except Exception as e:
    logging.error(f"❌ Error al crear esquema: {e}")
    conn.rollback()

def procesar_hoja_indice(nombre_hoja, df_hoja):
    """Procesa una hoja de índice y la sube a PostgreSQL"""
    tabla_pg = "indice_" + nombre_hoja.lower().replace("-", "_").replace(".", "_")
    
    # Crear tabla si no existe
    cursor.execute(f"""
        CREATE TABLE IF NOT EXISTS mapeo_indice."{tabla_pg}" (
            measurement_name TEXT,
            type TEXT,
            model TEXT,
            doc_count BIGINT
        );
    """)
    conn.commit()
    
    # Borrar datos anteriores
    cursor.execute(f'DELETE FROM mapeo_indice."{tabla_pg}"')
    conn.commit()
    
    # Filtrar y preparar datos
    datos = []
    for _, row in df_hoja.iterrows():
        # Saltar filas TOTAL
        if (str(row.get("measurement_name", "")).strip().upper() == "TOTAL" or 
            str(row.get("model", "")).strip().upper() == "TOTAL"):
            continue
        
        # Verificar que tenemos datos válidos
        if pd.notna(row.get("measurement_name")) and pd.notna(row.get("doc_count")):
            fila = (
                str(row["measurement_name"]), 
                str(row["type"]), 
                str(row["model"]), 
                int(row["doc_count"])
            )
            datos.append(fila)
    
    # Insertar nuevos datos
    for r in datos:
        cursor.execute(f'''
            INSERT INTO mapeo_indice."{tabla_pg}" (measurement_name, type, model, doc_count)
            VALUES (%s, %s, %s, %s)
        ''', r)
    conn.commit()
    logging.info(f"✅ {len(datos)} filas insertadas en tabla {tabla_pg}")

def procesar_hoja_diferencia(df_diferencia):
    """Procesa la hoja de diferencia y la sube a PostgreSQL"""
    tabla_pg = "tabla_diferencia"
    
    # Crear tabla si no existe
    cursor.execute(f"""
        CREATE TABLE IF NOT EXISTS mapeo_indice."{tabla_pg}" (
            index_name TEXT,
            docs_count BIGINT,
            combinacion_count BIGINT,
            diferencia BIGINT
        );
    """)
    conn.commit()
    
    # Borrar datos anteriores
    cursor.execute(f'DELETE FROM mapeo_indice."{tabla_pg}"')
    conn.commit()
    
    # Preparar datos
    datos = []
    for _, row in df_diferencia.iterrows():
        if pd.notna(row.get("index")) and pd.notna(row.get("docs_count")):
            fila = (
                str(row["index"]), 
                int(row["docs_count"]), 
                int(row["combinacion_count"]), 
                int(row["diferencia"])
            )
            datos.append(fila)
    
    # Insertar nuevos datos
    for r in datos:
        cursor.execute(f'''
            INSERT INTO mapeo_indice."{tabla_pg}" (index_name, docs_count, combinacion_count, diferencia)
            VALUES (%s, %s, %s, %s)
        ''', r)
    conn.commit()
    logging.info(f"✅ {len(datos)} filas insertadas en tabla_diferencia")

# Leer todas las hojas del archivo Excel
if os.path.exists(EXCEL_PATH):
    logging.info(f"📊 Procesando hojas del archivo Excel: {EXCEL_PATH}")
    
    # Leer todas las hojas con pandas
    hojas = pd.read_excel(EXCEL_PATH, sheet_name=None, engine="openpyxl")
    
    # Procesar cada hoja
    for nombre_hoja, df_hoja in hojas.items():
        # Saltar hojas especiales
        if nombre_hoja in ["Indices Validos", "Penultimos por Prefijo"]:
            logging.info(f"⏭️ Saltando hoja especial: {nombre_hoja}")
            continue
        
        if nombre_hoja == "diferencia":
            logging.info(f"🔎 Procesando hoja de diferencia...")
            procesar_hoja_diferencia(df_hoja)
        else:
            logging.info(f"🔎 Procesando hoja de índice: {nombre_hoja}")
            procesar_hoja_indice(nombre_hoja, df_hoja)

else:
    logging.error(f"❌ Archivo Excel no encontrado: {EXCEL_PATH}")

# Cerrar conexión
cursor.close()
conn.close()

# Limpiar archivos temporales
tmp_dir = "output/tmp"
if os.path.exists(tmp_dir):
    for archivo in os.listdir(tmp_dir):
        if archivo.endswith((".csv", ".xlsx")) and archivo != "indices.txt":
            ruta = os.path.join(tmp_dir, archivo)
            if os.path.isfile(ruta):
                os.remove(ruta)
    logging.info("🧹 Archivos temporales eliminados de 'tmp'.")

logging.info("✅ Proceso finalizado.")
