import subprocess
import sys

SCRIPTS = [
    "mapeonuevo.py",
    "script_slice.py",
    "mapeo_indice_indice.py",
    "conversion.py",
    "generar_diferencia.py"
]

def ejecutar_script(script):
    print(f"\n🚀 Ejecutando: {script}")
    resultado = subprocess.run([sys.executable, script])
    if resultado.returncode != 0:
        print(f"❌ Error al ejecutar {script}. Código de salida: {resultado.returncode}")
        sys.exit(resultado.returncode)
    print(f"✅ Finalizado: {script}")

def main():
    for script in SCRIPTS:
        ejecutar_script(script)
    print("\n🎯 Todos los scripts se ejecutaron correctamente.")

if __name__ == "__main__":
    main()
