import pandas as pd
import os

print("=== DEBUG SCRIPT PARA INDICES ===")

try:
    # Verificar archivo Excel
    print("1. Verificando archivo Excel...")
    df = pd.read_excel('output/indices_elasticsearch.xlsx', sheet_name='Penultimos por Prefijo')
    print(f"   - Archivo cargado exitosamente")
    print(f"   - Dimensiones: {df.shape}")
    
    # Verificar columnas
    print("\n2. Verificando columnas...")
    print(f"   - Columnas disponibles: {list(df.columns)}")
    
    if 'Index' in df.columns:
        print("   - ✅ Columna 'Index' encontrada")
        
        # Extraer índices
        print("\n3. Extrayendo índices...")
        indices = df['Index'].dropna().tolist()
        print(f"   - Se encontraron {len(indices)} índices válidos")
        
        if len(indices) > 0:
            print(f"   - Primeros 5 índices: {indices[:5]}")
            
            # Crear directorio y archivo
            print("\n4. Guardando archivo indices.txt...")
            os.makedirs('output/tmp', exist_ok=True)
            with open('output/tmp/indices.txt', 'w') as f:
                f.write('\n'.join(indices))
            print("   - ✅ Archivo 'output/tmp/indices.txt' creado exitosamente")
        else:
            print("   - ❌ No se encontraron índices válidos")
    else:
        print("   - ❌ Columna 'Index' NO encontrada")
        
except Exception as e:
    print(f"❌ Error: {e}")

print("\n=== FIN DEBUG ===")
